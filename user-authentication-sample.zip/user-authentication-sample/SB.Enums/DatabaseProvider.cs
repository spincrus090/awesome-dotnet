﻿namespace SB.Enums
{
    public enum DatabaseProvider
    {
        MicrosoftSQLServer = 1,
        MySQL = 2,
        Sqlite = 3,
        InMemory = 4,
        PostgreSQL = 5
    }
}
