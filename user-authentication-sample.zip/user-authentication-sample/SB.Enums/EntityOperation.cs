﻿namespace SB.Enums
{
    public enum EntityOperation
    {
        Added = 0,
        Modified = 1,
        Deleted = 2,
    }
}
