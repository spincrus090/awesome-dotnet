﻿using System;

namespace SB.Model.Entity.Interface
{
    public interface IBaseEntity
    {
        Guid Id { get; set; }
    }
}
