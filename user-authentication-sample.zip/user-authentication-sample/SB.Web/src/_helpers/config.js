export const config = {
    // Asp.net Core web api url
    apiUrl: 'https://localhost:44325'
};